package com.PracticaMoviles_GestorEquipos.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class EquiposActivity extends AppCompatActivity {

    private ArrayList<String> listaEquipos;
    private ArrayAdapter<String> adaptador;
    private EditText cambiarEquipos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_equipos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        listaEquipos=new ArrayList<>();
        listaEquipos.add("Barsa");
        listaEquipos.add("Madrid");
        listaEquipos.add("Valencia");

        //Aqui configuro el adaptador para poder mostrar la lista en un listView
        ListView listaVista=findViewById(R.id.lista_equipos);
        adaptador=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,listaEquipos);
        listaVista.setAdapter(adaptador);

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, R.layout.item_equipo, R.id.nombre_equipo, listaEquipos);
        listaVista.setAdapter(adaptador);

        //Ahora aqui las referencias de la vista y algunas de las cosas que le he puesto a la vista
        cambiarEquipos=findViewById(R.id.cambiar_equipos);
        Button btnAñadir=findViewById(R.id.btn_añadirEquipo);
        Button btnEliminar=findViewById(R.id.btn_eliminarEquipo);

        //Aqui es la funcionalidad del boton para añadir equipo
        btnAñadir.setOnClickListener(new View.OnClickListener(){

        @Override
        public void onClick(View v) {
            String nuevoEquipo = cambiarEquipos.getText().toString().trim();
            if (!nuevoEquipo.isEmpty()) {
                listaEquipos.add(nuevoEquipo);
                adaptador.notifyDataSetChanged();
                cambiarEquipos.setText("");
                Toast.makeText(EquiposActivity.this, "Equipo añadido", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(EquiposActivity.this, "El nombre del equipo no puede estar vacío", Toast.LENGTH_SHORT).show();
            }
        }
    });
    //FUNCIONALIDAD PARA ELIMINAR EQUIPOS
     btnEliminar.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             String equipoAEliminar = cambiarEquipos.getText().toString().trim();
             if (listaEquipos.contains(equipoAEliminar)) {
                 listaEquipos.remove(equipoAEliminar);
                 adaptador.notifyDataSetChanged();
                 cambiarEquipos.setText("");
                 Toast.makeText(EquiposActivity.this, "Equipo eliminado", Toast.LENGTH_SHORT).show();
             } else {
                 Toast.makeText(EquiposActivity.this, "El equipo no existe", Toast.LENGTH_SHORT).show();
             }
         }
     });



    }
}