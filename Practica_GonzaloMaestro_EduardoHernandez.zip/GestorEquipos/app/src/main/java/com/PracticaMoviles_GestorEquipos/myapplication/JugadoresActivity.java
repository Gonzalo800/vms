package com.PracticaMoviles_GestorEquipos.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class JugadoresActivity extends AppCompatActivity {

    private ArrayList<String> listaJugadores; // Lista para almacenar jugadores
    private ArrayAdapter<String> adaptadorJugadores; // Adaptador para la ListView
    private EditText cambiarJugador; // Campo para añadir o eliminar jugadores

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_jugadores);

        // Configurar bordes adaptables para dispositivos más modernos
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialización de la lista de jugadores
        listaJugadores = new ArrayList<>();
        listaJugadores.add("Messi");
        listaJugadores.add("Cristiano Ronaldo");
        listaJugadores.add("Iniesta");

        // Configurar referencias de la vista
        cambiarJugador = findViewById(R.id.cambiar_jugador);
        ListView listaVistaJugadores = findViewById(R.id.lista_jugadores);
        Button btnAñadirJugador = findViewById(R.id.btn_añadirJugador);
        Button btnEliminarJugador = findViewById(R.id.btn_eliminarJugador);

        // Configurar el adaptador para mostrar la lista en la ListView
        adaptadorJugadores = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaJugadores);
        listaVistaJugadores.setAdapter(adaptadorJugadores);

        // Botón para añadir jugadores
        btnAñadirJugador.setOnClickListener(v -> {
            String nuevoJugador = cambiarJugador.getText().toString().trim();
            if (!nuevoJugador.isEmpty()) {
                listaJugadores.add(nuevoJugador);
                adaptadorJugadores.notifyDataSetChanged(); // Actualizar la lista
                cambiarJugador.setText("");
                Toast.makeText(this, "Jugador añadido", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "El nombre del jugador no puede estar vacío", Toast.LENGTH_SHORT).show();
            }
        });

        // Botón para eliminar jugadores
        btnEliminarJugador.setOnClickListener(v -> {
            String jugadorAEliminar = cambiarJugador.getText().toString().trim();
            if (listaJugadores.contains(jugadorAEliminar)) {
                listaJugadores.remove(jugadorAEliminar);
                adaptadorJugadores.notifyDataSetChanged(); // Actualizar la lista
                cambiarJugador.setText("");
                Toast.makeText(this, "Jugador eliminado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Jugador no encontrado", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
